# State Machine

Checkout https://docs.google.com/drawings/d/1lkf6qcaAUGSpmrvhj5fGyXxWjwwRhtK4I3qu2CudsCU/edit?usp=sharing for state machine diagram

